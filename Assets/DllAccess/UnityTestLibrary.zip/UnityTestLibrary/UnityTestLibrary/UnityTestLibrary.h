#pragma once

typedef unsigned char byte;

// Custom function declarations goes here:
#ifdef __cplusplus
extern "C"
{
#endif
	// Just argument type of functions must be declared (no names):
	int __stdcall GetInt(int);
	float __stdcall GetFloat(float);
	bool __stdcall GetBool(bool);

	const wchar_t* __stdcall GetConstWString();
	const wchar_t* __stdcall GetWString(char*);
	const char* __stdcall GetString(char*);

	byte* __stdcall GetByteArray();
	
#ifdef __cplusplus
}
#endif
