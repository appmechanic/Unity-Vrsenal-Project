#include "UnityTestLibrary.h"
#include <string>	//Strings
#include <codecvt>	//Converter

using namespace std;
wstring_convert<codecvt_utf8_utf16<wchar_t>> converter;

//Persistent data variables:
string string8 = "An 8bit string";
wstring string16 = L"A 16bit string";
byte buffer[10] = { 1,2,3,4,5,6,7,8,9,0 };

// Function definitions:
extern "C"

// Common types:
int __stdcall GetInt(int n)
{
	return 2 + n;
}
float __stdcall GetFloat(float n)
{
	return 0.5f + n;
}
bool __stdcall GetBool(bool n)
{
	return !n;
}

// Strings:
const wchar_t* __stdcall GetConstWString()
{
	return L"A constant string";
}
const wchar_t* __stdcall GetWString(char* s1)	// Always receive strings through char*, never wchar_t*
{
	wstring message = string16 + converter.from_bytes(s1);	// Converting char* to wstring
	return message.c_str();
}
const char* __stdcall GetString(char* s1)
{
	string message = string8 + string(s1);
	return message.c_str();
}

// Array:
byte* __stdcall GetByteArray()
{
	return buffer;
}

// End of definitions.
