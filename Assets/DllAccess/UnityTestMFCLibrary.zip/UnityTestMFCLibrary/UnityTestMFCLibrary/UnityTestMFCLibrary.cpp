// UnityTestMFCLibrary.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "UnityTestMFCLibrary.h"

#include <string>	//Strings
#include <codecvt>	//Converter

using namespace std;
wstring_convert<codecvt_utf8_utf16<wchar_t>> converter;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

//
//TODO: If this DLL is dynamically linked against the MFC DLLs,
//		any functions exported from this DLL which call into
//		MFC must have the AFX_MANAGE_STATE macro added at the
//		very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

// CUnityTestMFCLibraryApp
// CUnityTestLibraryApp

//Persistent data variables:
string string8 = "An 8bit string";
wstring string16 = L"A 16bit string";
byte buffer[10] = { 1,2,3,4,5,6,7,8,9,0 };

// Function definitions:
extern "C"

// Common types:
int WINAPI GetInt(int n)
{
	return 2 + n;
}
float WINAPI GetFloat(float n)
{
	return 0.5f + n;
}
bool WINAPI GetBool(bool n)
{
	return !n;
}

// Strings:
const wchar_t* WINAPI GetConstWString()
{
	return L"A constant string";
}
const wchar_t* WINAPI GetWString(char* s1)	// Always receive strings through char*, never wchar_t*
{
	wstring message = string16 + converter.from_bytes(s1);	// Converting char* to wstring
	return message.c_str();
}
const char* WINAPI GetString(char* s1)
{
	string message = string8 + string(s1);
	return message.c_str();
}

// Array:
byte* WINAPI GetByteArray()
{
	return buffer;
}

// End of definitions.

BEGIN_MESSAGE_MAP(CUnityTestMFCLibraryApp, CWinApp)
END_MESSAGE_MAP()


// CUnityTestMFCLibraryApp construction

CUnityTestMFCLibraryApp::CUnityTestMFCLibraryApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CUnityTestMFCLibraryApp object

CUnityTestMFCLibraryApp theApp;


// CUnityTestMFCLibraryApp initialization

BOOL CUnityTestMFCLibraryApp::InitInstance()
{
	CWinApp::InitInstance();

	return TRUE;
}
