// UnityTestMFCLibrary.h : main header file for the UnityTestMFCLibrary DLL
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// CUnityTestMFCLibraryApp
// See UnityTestMFCLibrary.cpp for the implementation of this class
//

class CUnityTestMFCLibraryApp : public CWinApp
{
public:
	CUnityTestMFCLibraryApp();

// Overrides
public:
	virtual BOOL InitInstance();

	DECLARE_MESSAGE_MAP()
};

// Custom function declarations goes here:
#ifdef __cplusplus
extern "C"
{
#endif
	// Just argument type of functions must be declared (no names):
	int WINAPI GetInt(int);
	float WINAPI GetFloat(float);
	bool WINAPI GetBool(bool);

	const wchar_t* WINAPI GetConstWString();
	const wchar_t* WINAPI GetWString(char*);
	const char* WINAPI GetString(char*);

	byte* WINAPI GetByteArray();

#ifdef __cplusplus
}
#endif
